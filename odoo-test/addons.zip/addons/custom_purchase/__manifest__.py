# -*- coding: utf-8 -*-
{
    'name': '自定义采购模块',
    'version': '17.0.1.0.0',
    'category': 'Purchase',
    'summary': '扩展采购功能',
    'description': """
        自定义采购模块，扩展标准采购功能。
    """,
    'author': 'Galaxy',
    'website': 'https://example.com',
    'depends': ['purchase', 'custom_base'],
    'data': [],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
